/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registrario.paer1;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StoreMassage {

    // REQUIRED ARRAYS
    private static String[] sentMassege = new String[0];
    private static String[] disregardedMasseges = new String[0];
    private static String[] storedMasseges = new String[0];
    private static String[] massegeHash = new String[0];
    private static String[] messegeID = new String[0];

    // ADDITIONAL ARRAYS
    private static String[] recipient = new String[0];
    private static String[] senders = new String[0];

    private static String currentSender = "Unknown sender";

    private static final String JSON_FILE = "storedMessages.json";

    private static ArrayList<MessageRecord> messages =
            new ArrayList<>();

    // CONSTRUCTOR
    public StoreMassage() {
    }

    // MESSAGE RECORD
    private static class MessageRecord {

        String id;
        String hash;
        String recipient;
        String text;
        String status;
        String sender;

        MessageRecord(
                String id,
                String hash,
                String recipient,
                String text,
                String status,
                String sender) {

            this.id = id;
            this.hash = hash;
            this.recipient = recipient;
            this.text = text;
            this.status = status;
            this.sender = sender;
        }
    }

    // SET SENDER
    public static void setSender(String sender) {

        currentSender = sender;
    }

    // ADD MESSAGE
    public static void addMassege(
            String id,
            String hash,
            String recipientNumber,
            String text,
            String status) {

        MessageRecord newMessage = new MessageRecord(
                id,
                hash,
                recipientNumber,
                text,
                status,
                currentSender
        );

        messages.add(newMessage);

        populateArrays();

        if ("Stored".equalsIgnoreCase(status)) {

            saveStoredMessages();
        }
    }

    // POPULATE ARRAYS
    public static void populateArrays() {

        ArrayList<String> sent = new ArrayList<>();
        ArrayList<String> disregarded = new ArrayList<>();
        ArrayList<String> stored = new ArrayList<>();
        ArrayList<String> hashes = new ArrayList<>();
        ArrayList<String> ids = new ArrayList<>();
        ArrayList<String> recipients = new ArrayList<>();
        ArrayList<String> senderList = new ArrayList<>();

        for (MessageRecord message : messages) {

            hashes.add(message.hash);
            ids.add(message.id);
            recipients.add(message.recipient);
            senderList.add(message.sender);

            if ("Sent".equalsIgnoreCase(message.status)) {
                sent.add(message.text);
            }

            if ("Disregarded".equalsIgnoreCase(message.status)) {
                disregarded.add(message.text);
            }

            if ("Stored".equalsIgnoreCase(message.status)) {
                stored.add(message.text);
            }
        }

        sentMassege = sent.toArray(new String[0]);
        disregardedMasseges = disregarded.toArray(new String[0]);
        storedMasseges = stored.toArray(new String[0]);
        massegeHash = hashes.toArray(new String[0]);
        messegeID = ids.toArray(new String[0]);

        recipient = recipients.toArray(new String[0]);
        senders = senderList.toArray(new String[0]);
    }

    // LOAD STORED MESSAGES
    public static void loadStoredMasseges() {

        try {

            // Remove previously loaded stored messages
            ArrayList<MessageRecord> remaining =
                    new ArrayList<>();

            for (MessageRecord message : messages) {

                if (!"Stored".equalsIgnoreCase(message.status)) {
                    remaining.add(message);
                }
            }

            messages = remaining;

            if (!Files.exists(Paths.get(JSON_FILE))) {
                populateArrays();
                return;
            }

            String json = new String(
                    Files.readAllBytes(Paths.get(JSON_FILE)));

            Pattern objectPattern = Pattern.compile(
                    "\\{(.*?)\\}", Pattern.DOTALL);

            Matcher objectMatcher = objectPattern.matcher(json);

            while (objectMatcher.find()) {

                String object = objectMatcher.group(1);

                String id = getJSONValue(object, "messageID");
                String hash = getJSONValue(object, "messageHash");
                String number = getJSONValue(object, "recipient");
                String text = getJSONValue(object, "message");
                String sender = getJSONValue(object, "sender");

                if (id != null && hash != null
                        && number != null && text != null) {

                    if (sender == null) {
                        sender = "Unknown sender";
                    }

                    messages.add(new MessageRecord(
                            id, hash, number, text,
                            "Stored", sender));
                }
            }

            populateArrays();

        } catch (IOException e) {

            System.out.println("Could not read stored messages: "
                    + e.getMessage());
        }
    }

    // GET JSON VALUE
    private static String getJSONValue(
            String object,
            String key) {

        Pattern pattern = Pattern.compile(
                "\"" + key + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"");

        Matcher matcher = pattern.matcher(object);

        if (matcher.find()) {

            return matcher.group(1)
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\n", "\n")
                    .replace("\\r", "\r");
        }

        return null;
    }

    // DISPLAY STORED MESSAGES
    public static void displayStoredMessages() {

        boolean found = false;

        for (MessageRecord message : messages) {

            if ("Stored".equalsIgnoreCase(message.status)) {

                System.out.println("Sender: " + message.sender);
                System.out.println("Recipient: " + message.recipient);
                System.out.println("Message: " + message.text);
                System.out.println("-------------------------");

                found = true;
            }
        }

        if (!found) {
            System.out.println("No stored messages found.");
        }
    }

    // LONGEST STORED MESSAGE
    public static void longestStoredMessage() {

        MessageRecord longest = null;

        for (MessageRecord message : messages) {

            if ("Stored".equalsIgnoreCase(message.status)) {

                if (longest == null
                        || message.text.length() > longest.text.length()) {

                    longest = message;
                }
            }
        }

        if (longest == null) {

            System.out.println("No stored messages found.");

        } else {

            System.out.println("Longest stored message:");
            System.out.println(longest.text);
            System.out.println("Characters: " + longest.text.length());
        }
    }

    // SEARCH MESSAGE ID
    public static void searchMessageID(Scanner input) {

        System.out.println("Enter message ID:");
        String searchID = input.nextLine();

        boolean found = false;

        for (MessageRecord message : messages) {

            if ("Stored".equalsIgnoreCase(message.status)
                    && message.id.equals(searchID)) {

                System.out.println("Recipient: " + message.recipient);
                System.out.println("Message: " + message.text);

                found = true;
            }
        }

        if (!found) {
            System.out.println("Message ID not found.");
        }
    }

    // SEARCH RECIPIENT
    public static void searchRecipient(Scanner input) {

        System.out.println("Enter recipient cellphone number:");
        String searchRecipient = input.nextLine();

        boolean found = false;

        for (MessageRecord message : messages) {

            if ("Stored".equalsIgnoreCase(message.status)
                    && message.recipient.equals(searchRecipient)) {

                System.out.println("Message ID: " + message.id);
                System.out.println("Message: " + message.text);

                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    // DELETE MESSAGE USING HASH
    public static void deleteMessage(Scanner input) {

        System.out.println("Enter message hash:");
        String searchHash = input.nextLine();

        boolean found = false;

        for (int i = 0; i < messages.size(); i++) {

            MessageRecord message = messages.get(i);

            if ("Stored".equalsIgnoreCase(message.status)
                    && message.hash.equals(searchHash)) {

                messages.remove(i);
                found = true;
                break;
            }
        }

        if (found) {

            saveStoredMessages();
            populateArrays();

            System.out.println("Message successfully deleted.");

        } else {

            System.out.println("Message hash not found.");
        }
    }

    // DISPLAY FULL REPORT
    public static void displayReport() {

        boolean found = false;

        for (MessageRecord message : messages) {

            if ("Stored".equalsIgnoreCase(message.status)) {

                System.out.println("\n======================");
                System.out.println("MESSAGE REPORT");
                System.out.println("======================");

                System.out.println("Sender: " + message.sender);
                System.out.println("Recipient: " + message.recipient);
                System.out.println("Message ID: " + message.id);
                System.out.println("Message Hash: " + message.hash);
                System.out.println("Message: " + message.text);
                System.out.println("Status: " + message.status);

                found = true;
            }
        }

        if (!found) {
            System.out.println("No stored messages available.");
        }
    }

    // SAVE STORED MESSAGES TO JSON
    public static void saveStoredMessages() {

        try (FileWriter writer = new FileWriter(JSON_FILE)) {

            writer.write("[\n");

            boolean first = true;

            for (MessageRecord message : messages) {

                if ("Stored".equalsIgnoreCase(message.status)) {

                    if (!first) {
                        writer.write(",\n");
                    }

                    writer.write("  {\n");

                    writer.write("    \"messageID\": \""
                            + escapeJSON(message.id) + "\",\n");

                    writer.write("    \"messageHash\": \""
                            + escapeJSON(message.hash) + "\",\n");

                    writer.write("    \"recipient\": \""
                            + escapeJSON(message.recipient) + "\",\n");

                    writer.write("    \"message\": \""
                            + escapeJSON(message.text) + "\",\n");

                    writer.write("    \"sender\": \""
                            + escapeJSON(message.sender) + "\"\n");

                    writer.write("  }");

                    first = false;
                }
            }

            writer.write("\n]");

        } catch (IOException e) {

            System.out.println("Error saving messages: "
                    + e.getMessage());
        }
    }

    // ESCAPE JSON CHARACTERS
    private static String escapeJSON(String value) {

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    // STORED MESSAGES MENU
    public static void storedMessagesMenu(Scanner input) {

        loadStoredMasseges();

        boolean running = true;

        while (running) {

            System.out.println("\n===== STORED MESSAGES =====");

            System.out.println("1. Display sender and recipient");
            System.out.println("2. Display longest stored message");
            System.out.println("3. Search using message ID");
            System.out.println("4. Search messages by recipient");
            System.out.println("5. Delete message using hash");
            System.out.println("6. Display full message report");
            System.out.println("7. Back to main menu");

            System.out.print("Choose an option: ");

            String option = input.nextLine();

            switch (option) {

                case "1":
                    displayStoredMessages();
                    break;

                case "2":
                    longestStoredMessage();
                    break;

                case "3":
                    searchMessageID(input);
                    break;

                case "4":
                    searchRecipient(input);
                    break;

                case "5":
                    deleteMessage(input);
                    break;

                case "6":
                    displayReport();
                    break;

                case "7":
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}

