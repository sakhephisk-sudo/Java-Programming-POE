
     
package registrario.paer1;

import java.util.Scanner;

public class login {

    // LOGIN USER
    public static boolean loginUser(
            Scanner input,
            String storedusername,
            String storedPassword,
            String name,
            String surname) {

        System.out.println("\n====== LOGIN PAGE ======");

        System.out.println("Enter your username:");
        String enteredUsername = input.nextLine();

        System.out.println("Enter your password:");
        String enteredPassword = input.nextLine();

        if (enteredUsername.equals(storedusername)
                && enteredPassword.equals(storedPassword)) {

            return true;

        } else {

            return false;
        }
    }

    // RETURN LOGIN STATUS
    public static String returnLoginStatus(
           RegistrarioPart1  user,
            boolean loginSuccessful) {

        if (loginSuccessful) {

            return "Welcome " + user.name + " "
                    + user.surname
                    + ", it is great to see you again.";

        } else {

            return "Username or password incorrect, please try again.";
        }
    }
}
