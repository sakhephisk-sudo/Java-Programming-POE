

  package registrario.paer1;

import java.util.Scanner;

public class RegistrarioPart1 {

    String name;
    String surname;
    String username;
    String password;
    String phoneNum;

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

      RegistrarioPart1   user = new RegistrarioPart1();

        // NAME
        System.out.println("Please enter your name:");
        user.name = input.nextLine();

        // SURNAME
        System.out.println("Please enter your surname:");
        user.surname = input.nextLine();

        // USERNAME
        while (true) {

            System.out.println("Please enter your username:");
            user.username = input.nextLine();

            if (checkUserName(user.username)) {

                System.out.println("Username successfully captured.");
                break;

            } else {

                System.out.println("Username is not correctly formatted.");
                System.out.println("Username must contain an underscore.");
                System.out.println("Username must be no more than 5 characters.");
            }
        }

        // PASSWORD
        while (true) {

            System.out.println("Please enter your password:");
            user.password = input.nextLine();

            if (checkPassword(user.password)) {

                System.out.println("Password successfully captured.");
                break;

            } else {

                System.out.println("Password is not correctly formatted.");
                System.out.println("Password must be at least 8 characters.");
                System.out.println("Password must contain a capital letter.");
                System.out.println("Password must contain a number.");
                System.out.println("Password must contain a special character.");
            }
        }

        // CELLPHONE NUMBER
        while (true) {

            System.out.println("Please enter your cellphone number:");
            user.phoneNum = input.nextLine();

            if (checkPhoneNum(user.phoneNum)) {

                System.out.println("Phone number successfully added.");
                break;

            } else {

                System.out.println("Cellphone number incorrectly formatted.");
                System.out.println("Number must start with +27 and contain 9 digits after it.");
            }
        }

        // REGISTER USER
        String registrationMessage = registerUser(
                user.username,
                user.password,
                user.phoneNum,
                user.name,
                user.surname
        );

        System.out.println(registrationMessage);

        // LOGIN
        boolean loginSuccessful = login.loginUser(
                input,
                user.username,
                user.password,
                user.name,
                user.surname
        );

        // LOGIN STATUS
        String loginMessage = login.returnLoginStatus(
                user,
                loginSuccessful
        );

        System.out.println(loginMessage);

        // START QUICKCHAT
        if (loginSuccessful) {

            System.out.println("Welcome to QuickChat.");

            StoreMassage.setSender(user.name + " " + user.surname);

            QuickChat.startQuickChat(input);

        }

        input.close();
    }

    // CHECK USERNAME
    public static boolean checkUserName(String username) {

        return username != null
                && username.length() <= 5
                && username.contains("_");
    }

    // CHECK PASSWORD
    public static boolean checkPassword(String password) {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean capital = false;
        boolean number = false;
        boolean special = false;

        for (int i = 0; i < password.length(); i++) {

            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                capital = true;
            }

            if (Character.isDigit(ch)) {
                number = true;
            }

            if (!Character.isLetterOrDigit(ch)) {
                special = true;
            }
        }

        return capital && number && special;
    }

    // CHECK CELLPHONE NUMBER
    public static boolean checkPhoneNum(String phoneNum) {

        return phoneNum != null
                && phoneNum.matches("\\+27[0-9]{9}");
    }

    // REGISTER USER
    public static String registerUser(
            String username,
            String password,
            String phoneNum,
            String name,
            String surname) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted.";
        }

        if (!checkPassword(password)) {
            return "Password is not correctly formatted.";
        }

        if (!checkPhoneNum(phoneNum)) {
            return "Phone number incorrectly formatted.";
        }

        return "Registration successfully completed.";
    }
}
